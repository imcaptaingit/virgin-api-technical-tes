package com.virgingames.constants;

public class Endpoints {

    public static final String GET_ALL_DATA = "/roxor";
}
