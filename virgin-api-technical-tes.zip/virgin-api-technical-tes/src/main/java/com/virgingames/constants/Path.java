package com.virgingames.constants;

public class Path {

    public static final String BINGO = "/api/jackpots";


}
